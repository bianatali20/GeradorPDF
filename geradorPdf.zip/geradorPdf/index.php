<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Gerar PDF</title>
</head>

<body>
    <table>
        <tr>
            <td>Nome</td>
            <td>Curso</td>
            <td>Disciplina</td>
            <td>Média</td>
            <td>#</td>
        </tr>
        <br>
        <tr>
            <td>Gledson</td>
            <td>ADS</td>
            <td>Linguagem Técnica de Programação II</td>
            <td>8.5</td>
        </tr>
        <br>
        <tr>
            <td>Kennet</td>
            <td>ADS</td>
            <td>Linguagem Técnica de Programação II</td>
            <td>7</td>
        </tr>
        <br>
        <tr>
            <td>João Victor</td>
            <td>ADS</td>
            <td>Linguagem Técnica de Programação II</td>
            <td>9</td>
        </tr>
        <br>
        <tr>
            <td>Marcus</td>
            <td>ADS</td>
            <td>Linguagem Técnica de Programação II</td>
            <td>7.5</td>
        </tr>
        <br>
        <tr>
            <td>Lucas</td>
            <td>ADS</td>
            <td>Linguagem Técnica de Programação II</td>
            <td>6.8</td>
        </tr>
        <br>
        <tr>
            <td>Gabriel</td>
            <td>ADS</td>
            <td>Linguagem Técnica de Programação II</td>
            <td>7.7</td>
        </tr>
    </table>
    
    <a href="geraPdf.php"> Gerar PDF </a>
    
</body>

</html>


